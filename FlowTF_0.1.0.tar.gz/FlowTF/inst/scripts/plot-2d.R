##' Makes 2d plot of data and model
##'
##' @param ylist Data
##' @param obj Estimated model (from \code{flowmix_tf(ylist)})
plot_tf_2d <- function(ylist, obj, time = NULL){

  ## tt = 1
  tt = time
  yy = ylist[[tt]] %>% as_tibble()

  ## Plot data
  gg = yy %>% ggplot() +
    geom_point(aes(x = dim1, y = dim2), alpha = .1) +
    theme_bw() +
    theme(legend.position = 'none')


  ## Add mean
  mn = obj$mn %>% .[tt,,] %>% t()
  colnames(mn) = c("mean1", "mean2")
  mn = mn %>% as_tibble() %>% add_column(cluster = 1:3) %>% mutate(cluster = as.factor(cluster))
  prob = obj$prob %>% .[tt,]
  params = mn %>% add_column(prob = prob)
  gg = gg +
    geom_point(aes(x = mean1, y = mean2, size = prob, col = cluster),
               data = params) +
    theme(legend.position = "None") +
    ggtitle(paste0("Time = ", tt))

  ## Add contours
  els = lapply(1:numclust, function(iclust){
    onesigma = obj$sigma %>% .[iclust,,]
    el = ellipse::ellipse(x = onesigma,
                          centre = mn %>% subset(cluster==iclust) %>% as.numeric()) %>% as_tibble()
    el = el %>% add_column(cluster = iclust)
  }) %>% bind_rows() %>% mutate(cluster = as.factor(cluster))
  gg = gg + geom_path(aes(x = x, y = y, color = cluster, group = cluster), data = els, linetype = "dashed")
  return(gg)
}



my_ellips <- function(center = c(0,0), c = c95){

    ## Setup
    npoints = 100

    ## The "angles" to cover
    t <- seq(0, 2 * pi, len = npoints)

    ## The covariance matrix.
    ## Sigma <- matrix(c(1, rho, rho, 1), 2, 2)
    var1 = Sigma[1, 1]
    var2 = Sigma[2, 2]
    a <- sqrt(var1 * c * eigen(Sigma)$values[2])
    b <- sqrt(var2 * c * eigen(Sigma)$values[1])

    ## Form points with normal axes, "stretched" by a or b.
    x <- center[1] + a * cos(t)
    y <- center[2] + b * sin(t)
    X <- cbind(x, y)

    ## Rotate them according to the eigenvectors.
    ## (By right-multiplication)
    R <- eigen(Sigma)$vectors
    data.frame(X %*% R)
  if(FALSE){
    c95 <- qchisq(.95, df=2)
    rho = .5
    dat <- ellips(center=c(0, 0), c=c95, rho, npoints=100)
    ggplot() + geom_path(data=dat, aes(x=X1, y=X2), colour='blue')

  onesigma
  eval = eigen(onesigma)$values
  evec = eigen(onesigma)$vectors

  }
}
