library(FlowTF)
library(flowMeans)
library(dplyr)
library(ggplot2)
library(glmnet)
library(RcppHungarian)
library(mvtnorm)

# main function for "overfit" baseline -----------------------------------------------------------

#' Apply flowmeans sequentially and then cluster match
#'
#' @param ylist time series of cytograms
#' @param numclust number of clusters to be used
#'
#' @return
#' @export
#'
#' @examples
overfit <- function(ylist, numclust){
  fmns_obj <- lapply(ylist , FUN = fmns_individual, numclust = numclust)
  obj_overfit <- Hungarian_full_sequence(fmns_obj)

  y_df <- lapply(1:length(ylist), FUN = function(tt){
    data.frame(time = tt, Y = ylist[[tt]])
  }) %>% bind_rows() %>% as_tibble()
  ## y_df <- data.frame(do.call(rbind, ylist)) %>% as_tibble()
  y_df$cluster <- as.factor(unlist(obj_overfit$relabels))

  mu_df <- obj_overfit$mu %>% as_tibble() %>% setNames(c(1:numclust)) %>%
    tidyr::pivot_longer(cols = names(.), names_to = "cluster", values_to = "mu") %>%
    mutate(time = rep(1:length(ylist), time = rep(length(unique(cluster)), length(ylist))))

  plt <-
    ggplot() +
    geom_point(data = y_df, aes(x = time, y = Y, col = cluster), alpha = 0.1) +
    geom_line(data = mu_df, aes(x = time, y = mu, col = cluster), size = 2)  +
    scale_color_discrete(name = "Cluster", guide = 'none') + xlab("Time")
    ylab("Example Cytogram Measurement") + theme_bw() + theme(plot.title = element_text(hjust = 0.5, size = 16))

  return(plt)
}



# main function for "underfit" baseline -----------------------------------
#' Pool the entire series of cytograms, fit a flowMeans model, and re-aggregate parameters
#'
#' @param ylist time series of cytograms
#' @param numclust number of clusters to be used
#'
#' @return
#' @export
#'
#' @examples
underfit <- function(ylist, numclust){

  ## Basic checks
  dimdat = ncol(ylist[[1]])
  stopifnot(dimdat == 1)

  ## Transform data for \code{flowMeans()}.
  TT <- length(ylist)
  ntlist <- sapply(ylist, nrow)
  ylist_pooled <- do.call(rbind, ylist) %>% as_tibble()
  fmns_pooled <- flowMeans(x = ylist_pooled, NumC = numclust)
  labeled_ylist <- data.frame(y = ylist_pooled$Y, cluster = fmns_pooled@Label, time = rep(1:TT, times = ntlist))
  labeled_ylist %>% subset(time ==25) %>% as_tibble() %>%
    mutate(cluster = as.factor(cluster)) %>%
    ggplot(aes(x=y, fill = cluster)) + geom_histogram() + facet_wrap(~cluster)

  ## Get estimated model parameters.
  params <- labeled_ylist %>% group_by(cluster, time) %>%
    summarise(mn = mean(y), prob = n(), sigma = var(y), upper = quantile(y, 0.975), lower = quantile(y, 0.025)) %>%
    group_by(time) %>% mutate(prob = prob/sum(prob)) %>% ungroup()

  ymat_labeled = labeled_ylist %>% bind_rows() %>% mutate(cluster = as.factor(cluster))
  ggplot() +
    geom_point(aes(x=time, y = y, col = cluster), alpha = .1, data = ymat_labeled) +
    geom_line(aes(x=time,y=mn, col=cluster), data = params %>% select(time, cluster, mn) %>% mutate(cluster = as.factor(cluster)),
              size = 2) +
    geom_line(aes(x=time,y=upper, col=cluster), data = params %>% select(time, cluster, upper, lower) %>% mutate(cluster = as.factor(cluster)),
              size = 1, alpha = .5) +
    geom_line(aes(x=time,y=lower, col=cluster), data = params %>% select(time, cluster, upper, lower) %>% mutate(cluster = as.factor(cluster)),
              size = 1, alpha = .5) +
    scale_color_discrete(name = "Cluster", guide = 'none') + xlab("Time") + ggtitle("FlowMeans on pooled data.")

}



# performance metrics, this currently only works with 1D data -----------------------------------------------------

test_loglik <- function(new_ylist, mu, sigma, prob){
  
  TT <- length(new_ylist)
  N <- sum(sapply(new_ylist, nrow))
  Dl.dummy <- diag(rep(1, TT))
  numclust <- ncol(prob)
  
  # handle case where the array is only 2-D
  if(length(dim(mu)) < 3){
    mu <- array(mu, dim = c(nrow(mu), 1, ncol(mu)))
  }
  if(length(dim(sigma)) < 3){
    sigma <- array(sigma, dim = c(ncol(sigma), 1, nrow(sigma)))
  }
  
  loglik <- sapply(1:TT, function(tt){
      p.tt <- prob[tt,]
      yy.tt <- new_ylist[[tt]]
      if(dim(sigma)[3] > 1){
        sigma.tt <- sigma[,,tt]
      }
      else{
        sigma.tt <- sigma[,,]
      }
      return(log(sum(sapply(1:numclust, FUN = function(i.clust){
        p.tt[i.clust] * dmvnorm(yy.tt, mean = mu[tt,,i.clust], sigma = matrix(sigma.tt[i.clust]))
      }))))
  })
    
    
  return(sum(loglik))
}



test_maxresp <- function(new_ylist, new_labels, mu, sigma, prob){
  return(NULL)
}


# helper functions --------------------------------------------------------

fmns_individual <- function(ylist, numclust){
  # getting cluster labels from the peaks
  fmns_obj <- flowMeans(x = ylist, NumC = numclust)
  labeled_ylist <- data.frame(cluster = fmns_obj@Label, ylist)
  
  # calculating cluster parameters
  cluster_params <- labeled_ylist %>% group_by(cluster) %>% 
    summarise(mu = mean(Y), pi = n()/nrow(labeled_ylist), 
              sigma = ifelse(!is.na(var(Y)), var(Y), 1e-10))
  
  return(list(fmns_obj = fmns_obj, cluster_params = cluster_params))
}

kl_sym <- function(mu1, mu2, sigma1, sigma2){
  kl12 <- log(sigma2/sigma1) + (sigma1^2 + (mu1 - mu2)^2)/(2*sigma2^2) - 1/2
  kl21 <- log(sigma1/sigma2) + (sigma2^2 + (mu2 - mu1)^2)/(2*sigma1^2) - 1/2
  
  kl_sym <- 0.5*(kl12 + kl21)
  return(kl_sym)
}

# For two clusterings, return the distance matrix between each cluster using symmetrized KL divergence ----------

fmns_dist <- function(c1, c2){
  
  # make sure were using the same number of clusters
  assertthat::assert_that(nrow(c1) == nrow(c2))
  
  numc <- nrow(c1)
  # initialize distance matrix
  dist_cs <- matrix(0, ncol = numc, nrow = numc)
  
  # fill out distance matrix
  for(clust1 in 1:numc){
    for(clust2 in 1:numc){
      dist_cs[clust2, clust1] = kl_sym(mu1 = c1$mu[clust1], mu2 = c2$mu[clust2], 
                                       sigma1 = sqrt(c1$sigma[clust1]), sigma2 = sqrt(c2$sigma[clust2]))
    }
  }
  
  rownames(dist_cs) <- rep("C1", numc)
  colnames(dist_cs) <- rep("C2", numc)
  return(dist_cs)
}


# apply the hungarian matching algorithm to each time point

Hungarian_full_sequence <- function(fmns_obj){
  
  # initialize some objects
  TT <- length(fmns_obj)
  numc <- nrow(fmns_obj[[1]]$cluster_params)
  mu <- matrix(nrow = TT, ncol = numc)
  sigma <- matrix(nrow = TT, ncol = numc)
  pi <- matrix(nrow = TT, ncol = numc)
  costs <- rep(NA, TT)
  relabels <- list(fmns_obj[[1]]$fmns_obj@Label)
  
  # first row is spoken for
  mu[1,] <- fmns_obj[[1]]$cluster_params$mu
  sigma[1,] <- fmns_obj[[1]]$cluster_params$sigma
  pi[1,] <- fmns_obj[[1]]$cluster_params$pi
  
  # fill in the rest of the rows using hungarian matching
  for(tt in 2:TT){
    dt_to_tp1 <- fmns_dist(c1 = fmns_obj[[tt-1]]$cluster_params, c2 = fmns_obj[[tt]]$cluster_params)
    hng_tt <- HungarianSolver(dt_to_tp1)
    
    hng_order <- hng_tt$pairs %>% data.frame() %>% arrange(.[,2]) %>% .[,1]
    #hng_order <- hng_tt$pairs
    label.convert <- function(c1){hng_tt$pairs[c1,2]}
    
    fmns_obj[[tt]]$cluster_params <- fmns_obj[[tt]]$cluster_params[hng_order,]
    # for(ii in 1:numc){
    #   mu[tt,ii] <- fmns_obj[[tt]]$cluster_params$mu[label.convert(ii)]
    #   pi[tt,ii] <- fmns_obj[[tt]]$cluster_params$pi[label.convert(ii)]
    #   sigma[tt,ii] <- fmns_obj[[tt]]$cluster_params$sigma[label.convert(ii)]
    # }
    
    
    mu[tt,] <- fmns_obj[[tt]]$cluster_params$mu
    pi[tt,] <- fmns_obj[[tt]]$cluster_params$pi
    sigma[tt,] <- fmns_obj[[tt]]$cluster_params$sigma[hng_order]
    
    costs[tt] <- hng_tt$cost
    
    if(mean(abs(mu[tt,] - mu[tt-1,]))/max(abs(mu[tt,])) > 1){
      cat(paste("Bad Match at time", tt, "\n"))
    }
    # label converter
    
    relabels[[tt]] <- sapply(fmns_obj[[tt]]$fmns_obj@Label, label.convert)
    
    #browser()
  }
  
  return(list(mu = mu, pi = pi, sigma = sigma, costs = costs, relabels = relabels))
}

