#source("C:/Users/drain/Box Sync/USC_Stuff/Featureless_Flowmix/FlowPeaks_baseline/flowmeans_baselines.R")
library(FlowTF)
library(flowMeans)
library(dplyr)
library(ggplot2)
library(glmnet)
library(RcppHungarian)
library(mvtnorm)



#' Simulate data from the die off 3 cluster 1-D model
#'
#' @param TT number of time points
#' @param nt vector of length TT with number of particles in the cytogram at each time point tt
#' @param die_off_time a number in (0, 0.5) that specifies the start of the dieoff time
#' @param return_mean logical. Should the true means be returned?
#' @param return_pi logical. Should the true probabilities be returned?
#' @param kappa a constant controlling the intercept of the cluster 1 mean
#'
#' @return
#' @export
#'
#' @examples
gen_y_data_hybrid <- function(TT, nt, die_off_time = 0.45, return_mean = F, return_pi = F, kappa = 0.5){
  
  if(return_pi){
    pis <- lapply(1:TT, FUN = function(x){
      if(TT*die_off_time < x & x < (1-die_off_time)*TT){
        cluster_prob <- c(0.05, 0.95*rep(1/(3-1), 3-1))
      }
      else{
        cluster_prob <- rep(1/3, 3)
      }
      return(cluster_prob)
    })
    return(pis)
  }
  
  ys <- lapply(1:TT, FUN = function(x){
    
    Y <- vector(mode = "list", length = 2)
    mu <- vector(mode = "list", length = 2)
    times <- seq(-1, 1, length.out = TT)
    
    x_coef <- c(-1,1)
    
    if(TT*die_off_time < x & x < (1-die_off_time)*TT){
      cluster_prob <- c(0.05, 0.95*rep(1/(3-1), 3-1))
    }
    else{
      cluster_prob <- rep(1/3, 3)
    }
    
    clusters_count <- rmultinom(n = 1, size = nt[x], prob = cluster_prob)
    
    
    for(i in 1:3){
      if(i == 1){
        Y[[i]] <- replicate(clusters_count[i,1], kappa + times[x] + rnorm(1, sd = 0.4))
        mu[[i]] <- rep(times[x] + kappa, clusters_count[i,1])
      }
      if(i == 2){
        Y[[i]] <- replicate(clusters_count[i,1], sin(seq(-1, 1, length.out = TT)[x]*3.1415) + rnorm(1, sd = .5))
        mu[[i]] <- rep(sin(seq(-1, 1, length.out = TT)[x]*3.1415), clusters_count[i,1])
      }
      if(i == 3){
        Y[[i]] <- replicate(clusters_count[i,1], -3 + sin(seq(-1, 1, length.out = TT)[x]*6.282) + rnorm(1, sd = .35))
        mu[[i]] <- rep(-3+sin(seq(-1, 1, length.out = TT)[x]*6.282), clusters_count[i,1])
      }
    }
    
    Y <- unlist(Y)
    mu <- unlist(mu)
    cluster_assigns <- rep(1:3, times = clusters_count)
    if(return_mean){
      return(data.frame(time = x, Y = Y, mu = mu, cluster_assigns = cluster_assigns))
    }
    else{
      return(data.frame(Y = matrix(Y, ncol = 1)))}
  })
  ys
}


# auxillary functions -----------------------------------------------------

make_refit_filename <- function(iprob, imu, irep,
                                ## If simulations, then additional file names
                                sim = FALSE, isim = 1){
  filename = paste0(iprob, "-", imu, "-", irep, "-fit.Rdata")
  if(sim){filename = paste0(isim, "-", filename)} ## Temporary
  return(filename)
}

# full simulation code for running once ---------------------------------------------------------
# this generates training data, fits flowTF, underfitbaseline, and overfitbaseline
# model performance is assessed on a holdout set of equal size to the training set


run_sim_once <- function(destin, lambdas, lambda_pis, maxdev, nfold = 5, nrep = 5,
                         TT, mean_nt, die_off_time = 0.45, kappa = 0.5, seed = NULL){
  
  
  if(!is.null(seed)) set.seed(seed)
  # generate training data
  nt <- rpois(n = TT, lambda = mean_nt)
  y_list_train <- gen_y_data_hybrid(TT = TT, nt = nt, die_off_time = die_off_time, return_mean = F,
                                    return_pi = F, kappa = kappa)
  
  
  # generate test data
  y_list_test <- gen_y_data_hybrid(TT = TT, nt = nt, die_off_time = die_off_time, return_mean = F,
                                    return_pi = F, kappa = kappa)
  
  
  # flowTF refit
  cv.flowmix_tf(destin = destin, ylist = lapply(y_list_train, as.matrix), countslist = lapply(nt, FUN = function(x) rep(1, x)), maxdev = maxdev,
                numclust = 3, lambdas = lambdas, lambda_pis = lambda_pis, nfold = nfold, nrep = nrep, verbose = T,
                refit = T, save_meta = T, l_pi = 0, l = 2, X = NULL)
  cv.flowmix_tf(destin = destin, ylist = lapply(y_list_train, as.matrix), countslist = lapply(nt, FUN = function(x) rep(1, x)), maxdev = maxdev,
                numclust = 3, lambdas = lambdas, lambda_pis = lambda_pis, nfold = nfold, nrep = nrep, verbose = T,
                refit = F, save_meta = T, l_pi = 0, l = 2, X = NULL)
  
  cv_agg <- cv_aggregate(destin =  destin)
  best_inds <- which(cv_agg$cvscore.mat == min(cv_agg$cvscore.mat), arr.ind = T)   # take out the best model 

  fname <- make_refit_filename(iprob = best_inds[1], imu = best_inds[2], irep = 1)
  load(file = file.path(destin, fname), verbose = F)
  model.flowmix_tf <- res # save this model for later
  
  # overfit model
  model.overfit <- baseline_fmns_overfit(y_list_train, numclust = 3)

  # underfit model 
  model.underfit <- baseline_fmns_underfit(y_list_train, numclust = 3)
  
  # record loglikelihoods on test data
  loglik.overfit <- test_loglik(new_ylist = y_list_test, mu = model.overfit$mu, sigma = model.overfit$sigma, prob = model.overfit$pi)
  loglik.underfit <- test_loglik(new_ylist = y_list_test, mu = model.underfit$mu, sigma = model.underfit$sigma, prob = model.underfit$prob)
  loglik.ftf <- test_loglik(new_ylist = y_list_test, mu = model.flowmix_tf$mn, sigma = model.flowmix_tf$sigma, prob = model.flowmix_tf$prob)
  
  return(data.frame(Overfit = loglik.overfit, Underfit = loglik.underfit, FlowTF = loglik.ftf))
}


# sim0 <- run_sim_once(destin = "C:/Users/drain/Box Sync/USC_Stuff/Featureless_Flowmix/FlowPeaks_baseline/sim_CV_dir2/",
#              lambdas = seq(0.001, 0.05, length.out = 5), lambda_pis = seq(0.001, 0.05, length.out = 5), maxdev = 2, nfold = 5, nrep = 5,
#              TT = 50, mean_nt = 50, seed = 121)

#source("C:/Users/drain/Box Sync/USC_Stuff/Featureless_Flowmix/FlowTF/R/cv_tf.R")
set.seed(3022)
TT <- 50
nt <- rpois(TT, lambda = 50)
y_list_train <- lapply(gen_y_data_hybrid(TT = TT, nt = nt, return_mean = F,
                                  return_pi = F), as.matrix)

folds_hybrid <- make_cv_tf_folds(ylist = y_list_train, nfold = 5)
lambdas = c(0.02, 0.005)
l = 2
l_pi = 0
lambda_pi = c(0.005, 0.0005)

# running a singular job
profvis::profvis(one_job_tf(iprob = 2, imu = 1, ifold = 1, irep = 1, folds = folds_hybrid, numclust = 3, l = l, l_pi = l_pi,
                            destin = "C:/Users/drain/Box Sync/USC_Stuff/Featureless_Flowmix/flow_CV_out/profvis_files",
                            lambdas = lambdas, lambda_pis = lambda_pi, ylist = y_list_train, countslist = lapply(nt, FUN = function(x) rep(1, x))))

profvis::profvis(flowmix_tf_once(numclust = 3, l = l, l_pi = l_pi,
                            lambda = lambdas[1], lambda_pi = lambda_pi[2], ylist = y_list_train, countslist = lapply(nt, FUN = function(x) rep(1, x))))


