#' Fused LASSO for scalar inputs.
#'
#' @param z scalar input to be smoothed via the fused LASSO
#' @param lam  Fused LASSO smoothing parameter
#'
#' @return Estimates of the fused LASSO solution
#' @export prox
#'
#' @references All credit for writing this function goes to Ryan Tibshirani. See
#'   the original code for calling this function at
#'
#' @useDynLib FlowTF prox_dp
#' @export
prox <-  function(z, lam) {
  o <- .C("prox_dp",
          as.integer(length(z)),
          as.double(z),
          as.double(lam),
          as.double(numeric(length(z))),
          #  dup=FALSE,
          PACKAGE="FlowTF")

  return(o[[4]])
}
