#' FlowTF: Featureless Gating of Continuous Time Cytograms
#' @name FlowTF-package
#' @docType _PACKAGE
#' @importFrom Rcpp sourceCpp
#' @useDynLib FlowTF
#' @import dplyr
#' @import glmnet
#' @import abind
#' @import mvtnorm
#' @keywords trendfilter
NULL

usethis::use_build_ignore(c("figures", "script"))
